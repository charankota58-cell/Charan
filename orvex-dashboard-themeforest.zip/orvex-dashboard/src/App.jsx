import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  LayoutDashboard, PieChart as PieIcon, LineChart as MarketIcon, WalletCards,
  Settings, Search, Bell, ChevronDown, Menu, X, Sun, Moon, TrendingUp,
  TrendingDown, Copy, ExternalLink, ArrowUpRight, ArrowDownRight, Star,
  MoreHorizontal, Send, Download, ShieldCheck, Zap, Plus, ArrowLeftRight,
  QrCode, CheckCircle2, Clock3, XCircle, ChevronRight, Orbit
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, BarChart, Bar
} from "recharts";

/* ----------------------------- Mock / seed data ----------------------------- */

const COINS = [
  { id: "bitcoin", symbol: "BTC", name: "Bitcoin", price: 68420.32, change: 2.14, color: "#F7931A" },
  { id: "ethereum", symbol: "ETH", name: "Ethereum", price: 3542.11, change: 1.42, color: "#8DA6F5" },
  { id: "solana", symbol: "SOL", name: "Solana", price: 178.64, change: -3.28, color: "#9945FF" },
  { id: "binancecoin", symbol: "BNB", name: "BNB", price: 612.05, change: 0.63, color: "#F3BA2F" },
  { id: "ripple", symbol: "XRP", name: "XRP", price: 0.612, change: -1.05, color: "#66BFEA" },
  { id: "cardano", symbol: "ADA", name: "Cardano", price: 0.452, change: 4.87, color: "#3CC8C8" },
  { id: "dogecoin", symbol: "DOGE", name: "Dogecoin", price: 0.1621, change: -0.44, color: "#C3A634" },
  { id: "polkadot", symbol: "DOT", name: "Polkadot", price: 6.84, change: 3.05, color: "#E6007A" },
];

function seededSeries(seed, points, drift) {
  let v = seed, out = [];
  let s = seed * 999;
  for (let i = 0; i < points; i++) {
    s = (s * 9301 + 49297) % 233280;
    const rnd = s / 233280;
    v = v + (rnd - 0.48) * drift;
    out.push(Math.max(v, seed * 0.4));
  }
  return out;
}

const SPARKLINES = Object.fromEntries(
  COINS.map((c, i) => [c.symbol, seededSeries(c.price, 16, c.price * 0.03).map((y, x) => ({ x, y }))])
);

const BALANCE_HISTORY = {
  "24H": seededSeries(118400, 24, 900).map((y, x) => ({ label: `${x}:00`, value: Math.round(y) })),
  "7D": seededSeries(112000, 7, 4200).map((y, x) => ({ label: `Day ${x + 1}`, value: Math.round(y) })),
  "1M": seededSeries(98000, 30, 3600).map((y, x) => ({ label: `${x + 1}`, value: Math.round(y) })),
  "1Y": seededSeries(64000, 12, 9800).map((y, x) => ({ label: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][x], value: Math.round(y) })),
};

const HOLDINGS = [
  { symbol: "BTC", name: "Bitcoin", amount: 0.842, value: 57601.9, alloc: 42.1, change: 2.14 },
  { symbol: "ETH", name: "Ethereum", amount: 9.65, value: 34191.4, alloc: 25.0, change: 1.42 },
  { symbol: "SOL", name: "Solana", amount: 88.2, value: 15756.6, alloc: 11.5, change: -3.28 },
  { symbol: "BNB", name: "BNB", amount: 21.4, value: 13098.0, alloc: 9.6, change: 0.63 },
  { symbol: "XRP", name: "XRP", amount: 24500, value: 14994.0, alloc: 8.1, change: -1.05 },
  { symbol: "ADA", name: "Cardano", amount: 12800, value: 5785.6, alloc: 3.7, change: 4.87 },
];

const PIE_COLORS = ["#3B82F6", "#818CF8", "#34D399", "#FBBF24", "#F472B6", "#22D3EE"];

const TRANSACTIONS = [
  { id: 1, type: "receive", asset: "ETH", amount: 2.4, usd: 8501.1, addr: "0x91Fa...2eB4", time: "2m ago", status: "completed" },
  { id: 2, type: "swap", asset: "SOL → USDC", amount: 12.6, usd: 2251.2, addr: "Internal", time: "38m ago", status: "completed" },
  { id: 3, type: "send", asset: "BTC", amount: 0.081, usd: 5542.0, addr: "bc1q9d...84fk", time: "1h ago", status: "pending" },
  { id: 4, type: "receive", asset: "BNB", amount: 5.2, usd: 3182.7, addr: "0x4bE2...9a01", time: "3h ago", status: "completed" },
  { id: 5, type: "send", asset: "ADA", amount: 900, usd: 406.8, addr: "addr1q9...x7m2", time: "6h ago", status: "failed" },
  { id: 6, type: "swap", asset: "XRP → ETH", amount: 3100, usd: 1897.2, addr: "Internal", time: "1d ago", status: "completed" },
];

const NOTIFICATIONS = [
  { id: 1, title: "BTC crossed $68,000", desc: "Price alert triggered on your watchlist.", time: "5m ago", tone: "up" },
  { id: 2, title: "Send confirmed", desc: "0.081 BTC sent to bc1q9d...84fk", time: "1h ago", tone: "neutral" },
  { id: 3, title: "SOL down 3.2% today", desc: "Volatility alert for your holding.", time: "2h ago", tone: "down" },
];

const NAV_ITEMS = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "portfolio", label: "Portfolio", icon: PieIcon },
  { id: "market", label: "Market", icon: MarketIcon },
  { id: "wallet", label: "Wallet", icon: WalletCards },
];

const fmtUsd = (n, d = 2) => n.toLocaleString("en-US", { style: "currency", currency: "USD", minimumFractionDigits: d, maximumFractionDigits: d });
const fmtNum = (n) => n.toLocaleString("en-US", { maximumFractionDigits: n < 1 ? 4 : 2 });

/* ----------------------------- Theme tokens ----------------------------- */

function useTheme(isDark) {
  return isDark
    ? {
        bg: "bg-slate-950", panel: "bg-slate-900", panelAlt: "bg-slate-900/60",
        border: "border-slate-800", text: "text-slate-100", sub: "text-slate-400",
        subtle: "text-slate-500", hover: "hover:bg-slate-800/70", ring: "ring-slate-800",
        input: "bg-slate-900 border-slate-800 placeholder-slate-500",
        chip: "bg-slate-800/80 border-slate-700",
      }
    : {
        bg: "bg-slate-50", panel: "bg-white", panelAlt: "bg-slate-50",
        border: "border-slate-200", text: "text-slate-900", sub: "text-slate-500",
        subtle: "text-slate-400", hover: "hover:bg-slate-100", ring: "ring-slate-200",
        input: "bg-white border-slate-200 placeholder-slate-400",
        chip: "bg-slate-100 border-slate-200",
      };
}

/* ----------------------------- Small shared bits ----------------------------- */

function Trend({ value, size = "sm" }) {
  const up = value >= 0;
  const cls = up ? "text-emerald-400" : "text-rose-500";
  const bg = up ? "bg-emerald-400/10" : "bg-rose-500/10";
  const Icon = up ? ArrowUpRight : ArrowDownRight;
  return (
    <span className={`inline-flex items-center gap-0.5 rounded-md ${bg} ${cls} font-medium ${size === "sm" ? "text-xs px-1.5 py-0.5" : "text-sm px-2 py-1"}`}>
      <Icon className={size === "sm" ? "w-3 h-3" : "w-3.5 h-3.5"} />
      {Math.abs(value).toFixed(2)}%
    </span>
  );
}

function CoinGlyph({ symbol, color, size = 32 }) {
  return (
    <div
      className="rounded-full flex items-center justify-center font-bold text-white shrink-0"
      style={{ width: size, height: size, backgroundColor: color, fontSize: size * 0.36 }}
    >
      {symbol.slice(0, 1)}
    </div>
  );
}

function Sparkline({ data, color }) {
  return (
    <div className="w-24 h-10">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <Line type="monotone" dataKey="y" stroke={color} strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

function StatusPill({ status }) {
  const map = {
    completed: { icon: CheckCircle2, cls: "text-emerald-400 bg-emerald-400/10" },
    pending: { icon: Clock3, cls: "text-amber-400 bg-amber-400/10" },
    failed: { icon: XCircle, cls: "text-rose-500 bg-rose-500/10" },
  };
  const { icon: Icon, cls } = map[status];
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-md capitalize ${cls}`}>
      <Icon className="w-3.5 h-3.5" /> {status}
    </span>
  );
}

/* ----------------------------- Card wrapper ----------------------------- */

function Card({ t, className = "", children }) {
  return (
    <div className={`rounded-2xl border ${t.border} ${t.panel} shadow-sm ${className}`}>
      {children}
    </div>
  );
}

/* ----------------------------- Sidebar ----------------------------- */

function Sidebar({ t, isDark, page, setPage, mobileOpen, setMobileOpen }) {
  return (
    <>
      {mobileOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setMobileOpen(false)} />
      )}
      <aside
        className={`fixed z-50 lg:z-0 lg:sticky top-0 h-screen w-64 ${t.panel} border-r ${t.border} flex flex-col transition-transform duration-200
        ${mobileOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0`}
      >
        <div className={`h-16 flex items-center justify-between px-5 border-b ${t.border}`}>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-emerald-400 flex items-center justify-center">
              <Orbit className="w-4.5 h-4.5 text-white" strokeWidth={2.5} />
            </div>
            <span className={`font-semibold text-lg tracking-tight ${t.text}`}>ORVEX</span>
          </div>
          <button className="lg:hidden" onClick={() => setMobileOpen(false)}>
            <X className={`w-5 h-5 ${t.sub}`} />
          </button>
        </div>

        <nav className="flex-1 px-3 py-5 space-y-1">
          <p className={`px-3 text-xs font-semibold uppercase tracking-wider ${t.subtle} mb-2`}>Menu</p>
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = page === item.id;
            return (
              <button
                key={item.id}
                onClick={() => { setPage(item.id); setMobileOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors
                ${active
                  ? "bg-gradient-to-r from-blue-500/15 to-emerald-400/10 text-blue-400 border border-blue-500/20"
                  : `${t.sub} ${t.hover} border border-transparent`}`}
              >
                <Icon className="w-4.5 h-4.5" />
                {item.label}
                {active && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-blue-400" />}
              </button>
            );
          })}

          <p className={`px-3 text-xs font-semibold uppercase tracking-wider ${t.subtle} mt-6 mb-2`}>System</p>
          <button className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium ${t.sub} ${t.hover}`}>
            <Settings className="w-4.5 h-4.5" /> Settings
          </button>
        </nav>

        <div className={`p-4 border-t ${t.border}`}>
          <div className={`rounded-xl border ${t.border} ${t.panelAlt} p-3.5`}>
            <div className="flex items-center gap-2 mb-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span className={`text-xs font-semibold ${t.text}`}>Security check</span>
            </div>
            <p className={`text-xs ${t.sub} leading-relaxed`}>2FA active. Your wallet is protected against unauthorized access.</p>
          </div>
        </div>
      </aside>
    </>
  );
}

/* ----------------------------- Ticker rail ----------------------------- */

function TickerRail({ t, coins }) {
  const loop = [...coins, ...coins];
  return (
    <div className={`h-9 overflow-hidden border-b ${t.border} ${t.panelAlt}`}>
      <div className="flex items-center gap-8 whitespace-nowrap animate-orvex-ticker px-4">
        {loop.map((c, i) => (
          <div key={i} className="flex items-center gap-1.5 text-xs font-medium">
            <span className={t.sub}>{c.symbol}</span>
            <span className={t.text}>{fmtUsd(c.price, c.price < 1 ? 4 : 2)}</span>
            <span className={c.change >= 0 ? "text-emerald-400" : "text-rose-500"}>
              {c.change >= 0 ? "▲" : "▼"} {Math.abs(c.change).toFixed(2)}%
            </span>
          </div>
        ))}
      </div>
      <style>{`
        @keyframes orvex-ticker-scroll { from { transform: translateX(0); } to { transform: translateX(-50%); } }
        .animate-orvex-ticker { animation: orvex-ticker-scroll 34s linear infinite; }
      `}</style>
    </div>
  );
}

/* ----------------------------- Topbar ----------------------------- */

function Topbar({ t, isDark, setIsDark, setMobileOpen, coins }) {
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  return (
    <div className={`sticky top-0 z-30 ${t.panel} border-b ${t.border}`}>
      <div className="h-16 flex items-center gap-3 px-4 lg:px-6">
        <button className="lg:hidden" onClick={() => setMobileOpen(true)}>
          <Menu className={`w-5 h-5 ${t.text}`} />
        </button>

        <div className={`hidden md:flex items-center gap-2 flex-1 max-w-sm rounded-xl border ${t.input} px-3 py-2`}>
          <Search className={`w-4 h-4 ${t.subtle}`} />
          <input
            placeholder="Search assets, transactions..."
            className={`bg-transparent outline-none text-sm w-full ${t.text}`}
          />
        </div>

        <div className="flex-1 md:hidden" />

        <div className="flex items-center gap-2 ml-auto">
          <button
            onClick={() => setIsDark(!isDark)}
            className={`w-9 h-9 rounded-lg border ${t.border} flex items-center justify-center ${t.hover}`}
            aria-label="Toggle theme"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
          </button>

          <div className="relative">
            <button
              onClick={() => { setNotifOpen(!notifOpen); setProfileOpen(false); }}
              className={`w-9 h-9 rounded-lg border ${t.border} flex items-center justify-center relative ${t.hover}`}
            >
              <Bell className={`w-4 h-4 ${t.text}`} />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-rose-500" />
            </button>
            {notifOpen && (
              <div className={`absolute right-0 mt-2 w-80 rounded-2xl border ${t.border} ${t.panel} shadow-xl overflow-hidden`}>
                <div className={`px-4 py-3 border-b ${t.border} flex items-center justify-between`}>
                  <span className={`font-semibold text-sm ${t.text}`}>Notifications</span>
                  <span className="text-xs text-blue-400 font-medium">Mark all read</span>
                </div>
                {NOTIFICATIONS.map((n) => (
                  <div key={n.id} className={`px-4 py-3 border-b ${t.border} last:border-0 ${t.hover}`}>
                    <div className="flex items-start gap-2.5">
                      <span className={`mt-1 w-1.5 h-1.5 rounded-full shrink-0 ${n.tone === "up" ? "bg-emerald-400" : n.tone === "down" ? "bg-rose-500" : "bg-blue-400"}`} />
                      <div className="min-w-0">
                        <p className={`text-sm font-medium ${t.text}`}>{n.title}</p>
                        <p className={`text-xs ${t.sub} mt-0.5`}>{n.desc}</p>
                        <p className={`text-xs ${t.subtle} mt-1`}>{n.time}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className={`hidden sm:flex items-center gap-2 rounded-lg border ${t.border} ${t.panelAlt} pl-2.5 pr-3 py-1.5`}>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className={`text-xs font-medium ${t.text}`}>Connected: 0x71C...3a9</span>
          </div>

          <div className="relative">
            <button
              onClick={() => { setProfileOpen(!profileOpen); setNotifOpen(false); }}
              className="flex items-center gap-1.5"
            >
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-blue-500 to-emerald-400 flex items-center justify-center text-white text-sm font-semibold">
                A
              </div>
              <ChevronDown className={`hidden sm:block w-4 h-4 ${t.sub}`} />
            </button>
            {profileOpen && (
              <div className={`absolute right-0 mt-2 w-52 rounded-2xl border ${t.border} ${t.panel} shadow-xl overflow-hidden py-1`}>
                {["Profile", "Preferences", "API keys", "Sign out"].map((item) => (
                  <button key={item} className={`w-full text-left px-4 py-2.5 text-sm ${t.text} ${t.hover}`}>{item}</button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      <TickerRail t={t} coins={coins} />
    </div>
  );
}

/* ----------------------------- Overview page ----------------------------- */

function StatCard({ t, icon: Icon, label, value, sub, trend, accent }) {
  return (
    <Card t={t} className="p-5">
      <div className="flex items-start justify-between">
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${accent}`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        {trend !== undefined && <Trend value={trend} />}
      </div>
      <p className={`text-xs font-medium ${t.sub} mt-4`}>{label}</p>
      <p className={`text-2xl font-semibold ${t.text} mt-1 tracking-tight`}>{value}</p>
      {sub && <p className={`text-xs ${t.subtle} mt-1`}>{sub}</p>}
    </Card>
  );
}

function OverviewPage({ t, isDark, coins }) {
  const [range, setRange] = useState("7D");
  const data = BALANCE_HISTORY[range];
  const totalValue = HOLDINGS.reduce((s, h) => s + h.value, 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard t={t} icon={WalletCards} label="Total Balance" value={fmtUsd(totalValue, 0)} sub="Across 6 assets" trend={1.86} accent="bg-blue-500" />
        <StatCard t={t} icon={TrendingUp} label="24H Profit / Loss" value="+$2,148.32" sub="vs. yesterday" trend={2.31} accent="bg-emerald-500" />
        <StatCard t={t} icon={PieIcon} label="Portfolio Assets" value="6" sub="4 chains" accent="bg-indigo-500" />
        <StatCard t={t} icon={Zap} label="Active Positions" value="3" sub="1 pending swap" trend={-0.62} accent="bg-amber-500" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <Card t={t} className="xl:col-span-2 p-5">
          <div className="flex items-center justify-between flex-wrap gap-3 mb-2">
            <div>
              <p className={`text-sm font-semibold ${t.text}`}>Portfolio Value</p>
              <p className={`text-xs ${t.subtle}`}>Total balance movement</p>
            </div>
            <div className={`flex items-center rounded-lg border ${t.border} p-0.5`}>
              {Object.keys(BALANCE_HISTORY).map((r) => (
                <button
                  key={r}
                  onClick={() => setRange(r)}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                    range === r ? "bg-blue-500 text-white" : `${t.sub} ${t.hover}`
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
          <div className="h-72 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="balanceGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#3B82F6" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#3B82F6" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke={isDark ? "#1E293B" : "#E2E8F0"} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: isDark ? "#64748B" : "#94A3B8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: isDark ? "#64748B" : "#94A3B8" }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} width={45} />
                <Tooltip
                  contentStyle={{ background: isDark ? "#0F172A" : "#FFFFFF", border: `1px solid ${isDark ? "#1E293B" : "#E2E8F0"}`, borderRadius: 12, fontSize: 12 }}
                  formatter={(v) => [fmtUsd(v, 0), "Balance"]}
                />
                <Area type="monotone" dataKey="value" stroke="#3B82F6" strokeWidth={2.5} fill="url(#balanceGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card t={t} className="p-5">
          <p className={`text-sm font-semibold ${t.text} mb-1`}>Allocation</p>
          <p className={`text-xs ${t.subtle} mb-2`}>By asset value</p>
          <div className="h-44 relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={HOLDINGS} dataKey="value" nameKey="symbol" innerRadius={55} outerRadius={78} paddingAngle={3} stroke="none">
                  {HOLDINGS.map((h, i) => <Cell key={h.symbol} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                </Pie>
                <Tooltip
                  contentStyle={{ background: isDark ? "#0F172A" : "#FFFFFF", border: `1px solid ${isDark ? "#1E293B" : "#E2E8F0"}`, borderRadius: 12, fontSize: 12 }}
                  formatter={(v, n) => [fmtUsd(v, 0), n]}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <p className={`text-xs ${t.subtle}`}>Total</p>
              <p className={`text-sm font-semibold ${t.text}`}>{fmtUsd(totalValue, 0)}</p>
            </div>
          </div>
          <div className="space-y-2 mt-3">
            {HOLDINGS.slice(0, 4).map((h, i) => (
              <div key={h.symbol} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: PIE_COLORS[i % PIE_COLORS.length] }} />
                  <span className={t.sub}>{h.symbol}</span>
                </div>
                <span className={`font-medium ${t.text}`}>{h.alloc}%</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <Card t={t} className="xl:col-span-2 overflow-hidden">
          <div className={`flex items-center justify-between px-5 py-4 border-b ${t.border}`}>
            <p className={`text-sm font-semibold ${t.text}`}>Recent Transactions</p>
            <button className="text-xs font-medium text-blue-400 flex items-center gap-1">View all <ChevronRight className="w-3.5 h-3.5" /></button>
          </div>
          <div className="divide-y divide-slate-800/50">
            {TRANSACTIONS.slice(0, 5).map((tx) => (
              <TxRow key={tx.id} t={t} tx={tx} />
            ))}
          </div>
        </Card>

        <Card t={t} className="p-5">
          <div className="flex items-center justify-between mb-3">
            <p className={`text-sm font-semibold ${t.text}`}>Watchlist</p>
            <Star className="w-4 h-4 text-amber-400" />
          </div>
          <div className="space-y-3">
            {coins.slice(0, 5).map((c) => (
              <div key={c.symbol} className="flex items-center gap-3">
                <CoinGlyph symbol={c.symbol} color={c.color} size={30} />
                <div className="min-w-0 flex-1">
                  <p className={`text-sm font-medium ${t.text}`}>{c.symbol}</p>
                  <p className={`text-xs ${t.subtle}`}>{fmtUsd(c.price, c.price < 1 ? 4 : 2)}</p>
                </div>
                <Trend value={c.change} />
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

function TxRow({ t, tx }) {
  const iconMap = { send: Send, receive: Download, swap: ArrowLeftRight };
  const Icon = iconMap[tx.type];
  const toneMap = { send: "bg-rose-500/10 text-rose-500", receive: "bg-emerald-500/10 text-emerald-400", swap: "bg-blue-500/10 text-blue-400" };
  return (
    <div className={`flex items-center gap-3 px-5 py-3.5 ${t.hover}`}>
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${toneMap[tx.type]}`}>
        <Icon className="w-4 h-4" />
      </div>
      <div className="min-w-0 flex-1">
        <p className={`text-sm font-medium ${t.text} capitalize`}>{tx.type} {tx.asset}</p>
        <p className={`text-xs ${t.subtle}`}>{tx.addr} • {tx.time}</p>
      </div>
      <div className="text-right shrink-0">
        <p className={`text-sm font-medium ${t.text}`}>{fmtUsd(tx.usd, 0)}</p>
        <StatusPill status={tx.status} />
      </div>
    </div>
  );
}

/* ----------------------------- Portfolio page ----------------------------- */

function PortfolioPage({ t, isDark }) {
  const totalValue = HOLDINGS.reduce((s, h) => s + h.value, 0);
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <p className={`text-xl font-semibold ${t.text}`}>Portfolio</p>
          <p className={`text-sm ${t.sub}`}>{fmtUsd(totalValue, 0)} across {HOLDINGS.length} assets</p>
        </div>
        <button className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white text-sm font-medium px-4 py-2.5 rounded-xl transition-colors">
          <Plus className="w-4 h-4" /> Add Asset
        </button>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <Card t={t} className="xl:col-span-2 p-5">
          <p className={`text-sm font-semibold ${t.text} mb-4`}>Performance (30D)</p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={BALANCE_HISTORY["1M"]}>
                <defs>
                  <linearGradient id="portGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#34D399" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="#34D399" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke={isDark ? "#1E293B" : "#E2E8F0"} strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 10, fill: isDark ? "#64748B" : "#94A3B8" }} axisLine={false} tickLine={false} interval={4} />
                <YAxis tick={{ fontSize: 11, fill: isDark ? "#64748B" : "#94A3B8" }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`} width={45} />
                <Tooltip contentStyle={{ background: isDark ? "#0F172A" : "#FFFFFF", border: `1px solid ${isDark ? "#1E293B" : "#E2E8F0"}`, borderRadius: 12, fontSize: 12 }} formatter={(v) => [fmtUsd(v, 0), "Value"]} />
                <Area type="monotone" dataKey="value" stroke="#34D399" strokeWidth={2.5} fill="url(#portGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card t={t} className="p-5">
          <p className={`text-sm font-semibold ${t.text} mb-4`}>Allocation Breakdown</p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={HOLDINGS} dataKey="value" nameKey="symbol" innerRadius={0} outerRadius={80} stroke="none">
                  {HOLDINGS.map((h, i) => <Cell key={h.symbol} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: isDark ? "#0F172A" : "#FFFFFF", border: `1px solid ${isDark ? "#1E293B" : "#E2E8F0"}`, borderRadius: 12, fontSize: 12 }} formatter={(v, n) => [fmtUsd(v, 0), n]} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <Card t={t} className="overflow-hidden">
        <div className={`px-5 py-4 border-b ${t.border}`}>
          <p className={`text-sm font-semibold ${t.text}`}>Holdings</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className={`text-left ${t.subtle} text-xs uppercase tracking-wider`}>
                <th className="px-5 py-3 font-medium">Asset</th>
                <th className="px-5 py-3 font-medium">Amount</th>
                <th className="px-5 py-3 font-medium">Value</th>
                <th className="px-5 py-3 font-medium">Allocation</th>
                <th className="px-5 py-3 font-medium">24H</th>
              </tr>
            </thead>
            <tbody>
              {HOLDINGS.map((h, i) => (
                <tr key={h.symbol} className={`border-t ${t.border} ${t.hover}`}>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-2.5">
                      <CoinGlyph symbol={h.symbol} color={PIE_COLORS[i % PIE_COLORS.length]} size={28} />
                      <div>
                        <p className={`font-medium ${t.text}`}>{h.symbol}</p>
                        <p className={`text-xs ${t.subtle}`}>{h.name}</p>
                      </div>
                    </div>
                  </td>
                  <td className={`px-5 py-3.5 ${t.text}`}>{fmtNum(h.amount)}</td>
                  <td className={`px-5 py-3.5 font-medium ${t.text}`}>{fmtUsd(h.value, 0)}</td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-2 w-32">
                      <div className={`h-1.5 flex-1 rounded-full ${t.panelAlt}`}>
                        <div className="h-1.5 rounded-full bg-blue-500" style={{ width: `${h.alloc}%` }} />
                      </div>
                      <span className={`text-xs ${t.sub}`}>{h.alloc}%</span>
                    </div>
                  </td>
                  <td className="px-5 py-3.5"><Trend value={h.change} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ----------------------------- Market page ----------------------------- */

function MarketPage({ t, coins }) {
  const [tab, setTab] = useState("all");
  const filtered = tab === "gainers" ? coins.filter(c => c.change >= 0) : tab === "losers" ? coins.filter(c => c.change < 0) : coins;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <p className={`text-xl font-semibold ${t.text}`}>Market</p>
          <p className={`text-sm ${t.sub}`}>Live prices across {coins.length} assets</p>
        </div>
        <div className={`flex items-center rounded-lg border ${t.border} p-0.5`}>
          {[["all", "All"], ["gainers", "Gainers"], ["losers", "Losers"]].map(([id, label]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-md transition-colors ${tab === id ? "bg-blue-500 text-white" : `${t.sub} ${t.hover}`}`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <Card t={t} className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className={`text-left ${t.subtle} text-xs uppercase tracking-wider`}>
                <th className="px-5 py-3 font-medium">#</th>
                <th className="px-5 py-3 font-medium">Asset</th>
                <th className="px-5 py-3 font-medium">Price</th>
                <th className="px-5 py-3 font-medium">24H Change</th>
                <th className="px-5 py-3 font-medium">Last 16H</th>
                <th className="px-5 py-3 font-medium"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((c, i) => (
                <tr key={c.symbol} className={`border-t ${t.border} ${t.hover}`}>
                  <td className={`px-5 py-3.5 ${t.subtle}`}>{i + 1}</td>
                  <td className="px-5 py-3.5">
                    <div className="flex items-center gap-2.5">
                      <CoinGlyph symbol={c.symbol} color={c.color} size={28} />
                      <div>
                        <p className={`font-medium ${t.text}`}>{c.symbol}</p>
                        <p className={`text-xs ${t.subtle}`}>{c.name}</p>
                      </div>
                    </div>
                  </td>
                  <td className={`px-5 py-3.5 font-medium ${t.text}`}>{fmtUsd(c.price, c.price < 1 ? 4 : 2)}</td>
                  <td className="px-5 py-3.5"><Trend value={c.change} /></td>
                  <td className="px-5 py-3.5"><Sparkline data={SPARKLINES[c.symbol]} color={c.change >= 0 ? "#34D399" : "#F43F5E"} /></td>
                  <td className="px-5 py-3.5">
                    <button className={`p-1.5 rounded-md ${t.hover}`}><Star className={`w-4 h-4 ${t.subtle}`} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ----------------------------- Wallet page ----------------------------- */

function WalletPage({ t }) {
  const [copied, setCopied] = useState(false);
  const address = "0x71C7656EC7ab88b098defB751B7401B5f6d83a9";
  const totalValue = HOLDINGS.reduce((s, h) => s + h.value, 0);

  return (
    <div className="space-y-6">
      <Card t={t} className="p-6 bg-gradient-to-br from-blue-500/10 via-transparent to-emerald-400/10">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <p className={`text-xs font-medium ${t.subtle} mb-1`}>Connected Wallet</p>
            <div className="flex items-center gap-2">
              <p className={`text-lg font-semibold ${t.text} font-mono`}>{address.slice(0, 6)}...{address.slice(-4)}</p>
              <button
                onClick={() => { navigator.clipboard.writeText(address); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
                className={`p-1.5 rounded-md ${t.hover}`}
              >
                <Copy className={`w-3.5 h-3.5 ${t.subtle}`} />
              </button>
              {copied && <span className="text-xs text-emerald-400">Copied</span>}
            </div>
            <p className={`text-xs ${t.subtle} mt-1 flex items-center gap-1`}>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> Connected via MetaMask
            </p>
          </div>
          <div className="text-right">
            <p className={`text-xs font-medium ${t.subtle} mb-1`}>Total Value</p>
            <p className={`text-2xl font-semibold ${t.text}`}>{fmtUsd(totalValue, 0)}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-3 mt-5">
          <button className="flex items-center gap-2 bg-blue-500 hover:bg-blue-600 text-white text-sm font-medium px-4 py-2.5 rounded-xl transition-colors">
            <Send className="w-4 h-4" /> Send
          </button>
          <button className={`flex items-center gap-2 border ${t.border} ${t.text} text-sm font-medium px-4 py-2.5 rounded-xl ${t.hover} transition-colors`}>
            <Download className="w-4 h-4" /> Receive
          </button>
          <button className={`flex items-center gap-2 border ${t.border} ${t.text} text-sm font-medium px-4 py-2.5 rounded-xl ${t.hover} transition-colors`}>
            <ArrowLeftRight className="w-4 h-4" /> Swap
          </button>
          <button className={`flex items-center gap-2 border ${t.border} ${t.text} text-sm font-medium px-4 py-2.5 rounded-xl ${t.hover} transition-colors`}>
            <QrCode className="w-4 h-4" /> QR Code
          </button>
        </div>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <Card t={t} className="xl:col-span-1 p-5">
          <p className={`text-sm font-semibold ${t.text} mb-4`}>Asset Balances</p>
          <div className="space-y-4">
            {HOLDINGS.map((h, i) => (
              <div key={h.symbol} className="flex items-center gap-3">
                <CoinGlyph symbol={h.symbol} color={PIE_COLORS[i % PIE_COLORS.length]} size={32} />
                <div className="min-w-0 flex-1">
                  <p className={`text-sm font-medium ${t.text}`}>{h.symbol}</p>
                  <p className={`text-xs ${t.subtle}`}>{fmtNum(h.amount)} {h.symbol}</p>
                </div>
                <p className={`text-sm font-medium ${t.text}`}>{fmtUsd(h.value, 0)}</p>
              </div>
            ))}
          </div>
        </Card>

        <Card t={t} className="xl:col-span-2 overflow-hidden">
          <div className={`flex items-center justify-between px-5 py-4 border-b ${t.border}`}>
            <p className={`text-sm font-semibold ${t.text}`}>Transaction History</p>
            <button className={`p-1.5 rounded-md ${t.hover}`}><MoreHorizontal className={`w-4 h-4 ${t.subtle}`} /></button>
          </div>
          <div className="divide-y divide-slate-800/50">
            {TRANSACTIONS.map((tx) => <TxRow key={tx.id} t={t} tx={tx} />)}
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ----------------------------- App shell ----------------------------- */

export default function App() {
  const [isDark, setIsDark] = useState(true);
  const [page, setPage] = useState("overview");
  const [mobileOpen, setMobileOpen] = useState(false);
  const [coins, setCoins] = useState(COINS);
  const t = useTheme(isDark);

  useEffect(() => {
    let cancelled = false;
    async function loadPrices() {
      try {
        const ids = COINS.map((c) => c.id).join(",");
        const res = await fetch(`https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&ids=${ids}&order=market_cap_desc`);
        if (!res.ok) throw new Error("bad response");
        const json = await res.json();
        if (cancelled || !Array.isArray(json)) return;
        setCoins((prev) =>
          prev.map((c) => {
            const live = json.find((j) => j.id === c.id);
            return live
              ? { ...c, price: live.current_price ?? c.price, change: live.price_change_percentage_24h ?? c.change }
              : c;
          })
        );
      } catch (e) {
        // silent fallback to mock/seed data if the live API is unreachable
      }
    }
    loadPrices();
    const interval = setInterval(loadPrices, 45000);
    return () => { cancelled = true; clearInterval(interval); };
  }, []);

  return (
    <div className={`min-h-screen flex ${t.bg}`}>
      <Sidebar t={t} isDark={isDark} page={page} setPage={setPage} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <div className="flex-1 min-w-0 flex flex-col">
        <Topbar t={t} isDark={isDark} setIsDark={setIsDark} setMobileOpen={setMobileOpen} coins={coins} />
        <main className="flex-1 p-4 lg:p-6">
          {page === "overview" && <OverviewPage t={t} isDark={isDark} coins={coins} />}
          {page === "portfolio" && <PortfolioPage t={t} isDark={isDark} />}
          {page === "market" && <MarketPage t={t} coins={coins} />}
          {page === "wallet" && <WalletPage t={t} />}
        </main>
      </div>
    </div>
  );
}
