# Orvex — Crypto Dashboard Admin Template

Thank you for purchasing Orvex! This documentation will guide you through installation, setup and customization — no advanced coding experience required.

---

## 1. What's Included

- Full React 18 + Tailwind CSS crypto/wallet dashboard
- 4 pages: Overview, Portfolio, Market, Wallet
- Light & Dark mode toggle
- Live-updating price cards (via CoinGecko public API, with offline fallback demo data)
- Interactive charts (area, line, pie) built with Recharts
- Fully responsive layout (desktop, tablet, mobile with collapsible sidebar)
- Clean, componentized code — easy to extend or restyle

---

## 2. Requirements

Before installing, make sure you have the following installed on your computer:

- **Node.js** version 18 or higher (download from nodejs.org)
- A code editor (VS Code recommended)
- Basic familiarity with the command line/terminal

---

## 3. Installation

1. Unzip the template package.
2. Open a terminal inside the extracted folder.
3. Install dependencies:
   ```
   npm install
   ```
4. Start the local development server:
   ```
   npm run dev
   ```
5. Open the URL shown in your terminal (usually `http://localhost:5173`) in your browser.

---

## 4. Building for Production

When you're ready to deploy your dashboard to a live server:

```
npm run build
```

This creates an optimized `dist/` folder. Upload the contents of `dist/` to any static hosting provider (Vercel, Netlify, cPanel, etc.).

---

## 5. File Structure

```
orvex-dashboard/
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
├── public/
│   └── favicon.svg
└── src/
    ├── main.jsx        (app entry point)
    ├── index.css        (Tailwind imports + global styles)
    └── App.jsx          (all dashboard components & pages)
```

---

## 6. Customization

- **Colors & Theme:** Edit the `useTheme()` function inside `App.jsx` to change dark/light color tokens, or extend `tailwind.config.js` for custom brand colors.
- **Coins / Holdings / Transactions:** All demo data lives at the top of `App.jsx` inside the `COINS`, `HOLDINGS`, and `TRANSACTIONS` arrays — replace with your own data or connect to your backend/API.
- **Live Price Feed:** The dashboard fetches live prices from the public CoinGecko API on load and every 45 seconds. To disable this and use only static demo data, remove the `useEffect` block inside the `App` component in `App.jsx`.
- **Icons:** Powered by `lucide-react` — browse available icons at lucide.dev and swap freely.
- **Charts:** Powered by `recharts` — fully documented at recharts.org.

---

## 7. Support

For any questions regarding this template, please reach out through your item's comment section on ThemeForest, and we'll be happy to help.

---

## 8. Credits

- React — reactjs.org
- Tailwind CSS — tailwindcss.com
- Recharts — recharts.org
- Lucide Icons — lucide.dev
- Price data (demo/live mode) — CoinGecko API
